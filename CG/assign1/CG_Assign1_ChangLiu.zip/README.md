README
===


##**Reference**

1) [ellipse algorithm paper1](http://www.eazynotes.com/notes/computer-graphics/algorithms/mid-point-elliplse-algorithm.pdf)

2) [ellipse algorithm paper2](http://winnyefanho.net/research/MEA.pdf)

3) [Bresenham midpoint line algorithm]( http://en.wikipedia.org/wiki/Midpoint_circle_algorithm)
